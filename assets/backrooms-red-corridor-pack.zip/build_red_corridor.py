#!/usr/bin/env python3
"""Build a Backrooms-inspired red corridor environment from the supplied visual reference."""
import os, math
import numpy as np
import trimesh
from trimesh.visual.material import PBRMaterial

OUT='/home/ubuntu/backrooms-red-corridor'
scene=trimesh.Scene()

# Colors kept in restrained dark reds, near-black shadows, and hot warning red.
MATS={
 'concrete':PBRMaterial(name='Deep red painted concrete',baseColorFactor=[.145,.008,.014,1],metallicFactor=0,roughnessFactor=.94),
 'wall':PBRMaterial(name='Oxide red corridor wall',baseColorFactor=[.205,.008,.017,1],metallicFactor=0,roughnessFactor=.87),
 'panel':PBRMaterial(name='Dark inset wall panel',baseColorFactor=[.075,.004,.01,1],metallicFactor=0,roughnessFactor=.9),
 'trim':PBRMaterial(name='Blackened red steel trim',baseColorFactor=[.055,.008,.012,1],metallicFactor=.28,roughnessFactor=.62),
 'floor':PBRMaterial(name='Scuffed crimson floor',baseColorFactor=[.11,.008,.014,1],metallicFactor=0,roughnessFactor=.97),
 'door':PBRMaterial(name='Shadowed red door',baseColorFactor=[.095,.004,.009,1],metallicFactor=.08,roughnessFactor=.85),
 'lamp':PBRMaterial(name='Red lamp diffuser',baseColorFactor=[1,.015,.03,1],emissiveFactor=[1,.002,.008],metallicFactor=0,roughnessFactor=.25),
 'exit':PBRMaterial(name='Luminous EXIT letters',baseColorFactor=[1,.25,.27,1],emissiveFactor=[1,.12,.16],metallicFactor=0,roughnessFactor=.25),
 'black':PBRMaterial(name='Near-black recess',baseColorFactor=[.012,.001,.002,1],metallicFactor=0,roughnessFactor=1),
 'edge':PBRMaterial(name='Weathered bright red edge',baseColorFactor=[.36,.006,.018,1],metallicFactor=.08,roughnessFactor=.72),
}

def add(mesh,name,material):
    mesh.visual.material=MATS[material]
    scene.add_geometry(mesh,node_name=name,geom_name=name)

def box(name,center,size,material):
    m=trimesh.creation.box(extents=size)
    m.apply_translation(center)
    add(m,name,material)

def beam(name,a,b,width,depth,material):
    a=np.array(a,float);b=np.array(b,float);v=b-a;L=np.linalg.norm(v)
    if L<1e-8:return
    m=trimesh.creation.box(extents=[width,depth,L])
    m.apply_transform(trimesh.geometry.align_vectors([0,0,1],v/L));m.apply_translation((a+b)/2)
    add(m,name,material)

# Long narrow shell: floor, ceiling, and two tall enclosing walls.
L=32.0; W=4.7; H=3.2; wall_t=.20
box('Continuous corridor floor',(0,-.12,L/2),(W,.24,L),'floor')
box('Low ceiling slab',(0,H+.10,L/2),(W,.20,L),'panel')
for side,label in [(-1,'Left'),(1,'Right')]:
    x=side*(W/2+wall_t/2)
    box(f'{label} continuous enclosing wall',(x,H/2,L/2),(wall_t,H,L),'wall')
    # Long dark edge rails and intermittent raised structural ribs.
    box(f'{label} lower baseboard',(side*W/2,.16,L/2),(.11,.30,L),'trim')
    box(f'{label} upper wall crown',(side*W/2,H-.14,L/2),(.09,.16,L),'edge')
    for z in np.arange(.7,L-.5,2.05):
        box(f'{label} vertical wall rib {z:.1f}',(side*(W/2-.065),1.58,z),(.10,2.7,.045),'edge')
    # Repeating dark wall panels between the ribs.
    for z in np.arange(1.7,L-1,4.1):
        box(f'{label} inset shadow panel {z:.1f}',(side*(W/2-.08),1.66,z),(.025,1.95,1.85),'panel')

# Alternating heavy doors / recesses, with dark cavities and red-lit jambs.
for side,label in [(-1,'Left'),(1,'Right')]:
    for i,z in enumerate([2.3,7.4,12.5,17.6,22.7,27.8],1):
        x=side*(W/2-.10)
        # Shallow black reveal behind the dark door leaf.
        box(f'{label} doorway recess {i}',(x,1.31,z),(.055,2.46,1.22),'black')
        leafx=side*(W/2-.055)
        box(f'{label} red door leaf {i}',(leafx,1.28,z),(.065,2.30,1.02),'door')
        # Frame rails and lintel.
        frame_x=side*(W/2-.015)
        for dz in [-.59,.59]:
            box(f'{label} door jamb {i} {dz:+.2f}',(frame_x,1.30,z+dz),(.065,2.58,.105),'trim')
        box(f'{label} door header {i}',(frame_x,2.61,z),(.07,.12,1.28),'edge')
        box(f'{label} door kick plate {i}',(side*(W/2-.005),.27,z),(.045,.40,1.03),'trim')
        # Obscure inset aperture and a tiny dark handle; varied X-bar on some doors.
        box(f'{label} door inset {i}',(side*(W/2-.012),1.45,z),(.023,1.25,.67),'panel')
        box(f'{label} door handle {i}',(side*(W/2-.002),1.25,z+.36),(.025,.055,.12),'edge')
        if (i+ (side>0))%2==0:
            beam(f'{label} diagonal door brace {i}',(side*(W/2-.004),.47,z-.44),(side*(W/2-.004),2.26,z+.44),.045,.028,'edge')
            beam(f'{label} diagonal door brace slash {i}',(side*(W/2-.004),.52,z+.42),(side*(W/2-.004),2.20,z-.42),.03,.022,'trim')

# 5x7 low-res block lettering, extruded as small emissive rectangles on sign faces.
FONT={
 'E':['11111','10000','10000','11110','10000','10000','11111'],
 'X':['10001','10001','01010','00100','01010','10001','10001'],
 'I':['11111','00100','00100','00100','00100','00100','11111'],
 'T':['11111','00100','00100','00100','00100','00100','00100'],
}
def exit_sign(index,z,scale=.044):
    width=.96;height=.34;y=2.77
    # Suspended dark sign box and red inset, facing the camera down corridor (-Z).
    box(f'EXIT sign housing {index}',(0,y,z),(width,.40,.105),'trim')
    box(f'EXIT sign red face {index}',(0,y,z-.057),(width-.10,.30,.018),'door')
    # Letter blocks (front surface is toward negative Z); build sharp, readable EXIT glyphs.
    word='EXIT';gap=1;cells=sum(len(FONT[c][0]) for c in word)+gap*(len(word)-1)
    x0=-cells*scale/2
    # Camera views the sign face from -Z, which reverses horizontal world X.
    # Place glyphs in reverse world order so they read EXIT left-to-right onscreen.
    for ch in word[::-1]:
        for row,line in enumerate(FONT[ch]):
            # Each bitmap glyph also mirrors because its visible face is toward -Z.
            for col,pixel in enumerate(line[::-1]):
                if pixel=='1':
                    x=x0+(col+.5)*scale
                    yy=y+((6-row)-3)*scale
                    box(f'EXIT sign {index} letter {ch} pixel {row}-{col}',(x,yy,z-.071),(scale*.78,scale*.78,.014),'exit')
        x0+=(5+gap)*scale

for i,z in enumerate([1.45,4.65,7.85,11.05,14.25,17.45,20.65,23.85,27.05,30.25],1):
    exit_sign(i,z,.031)

# Receding ceiling lamps and small metal collars create the tunnel's repeating rhythm.
for i,z in enumerate(np.arange(.75,L-.35,1.72),1):
    box(f'Ceiling light dark collar {i}',(0,H-.035,z),(.48,.08,.48),'trim')
    box(f'Ceiling light red diffuser {i}',(0,H-.082,z),(.36,.018,.36),'lamp')
    # Short ceiling ribs at the light stations.
    for side in [-1,1]:
        box(f'Ceiling station rib {i} {side:+d}',(side*.50,H-.03,z),(.08,.07,.50),'edge')

# Floor panel joints and low raised lane edging enhance the corridor perspective.
for z in np.arange(.0,L,.95):
    box(f'Floor transverse seam {z:.2f}',(0,.004,z),(W-.30,.008,.018),'edge')
for side in [-1,1]:
    beam(f'Floor side runner {side:+d}',(side*1.96,.025,0),(side*1.96,.025,L),.028,.035,'trim')

# Atmospheric metadata; viewer supplies matching actual point lights and fog.
scene.metadata['title']='Backrooms-Inspired Red Corridor - 3D Environment Concept'
scene.metadata['units']='meters'
scene.metadata['description']='Original 3D environment inspired by the supplied reference: a dark, narrow red corridor with repeated emissive EXIT signs, ominous side doors, panels, ceiling lights and a vanishing point. Concept artwork only.'
scene.export(f'{OUT}/backrooms_red_corridor.glb')
scene.export(f'{OUT}/backrooms_red_corridor.obj',file_type='obj')
print('Exported',len(scene.geometry),'named components')
print('Bounds (m):',scene.bounds.tolist())
print('GLB bytes:',os.path.getsize(f'{OUT}/backrooms_red_corridor.glb'))

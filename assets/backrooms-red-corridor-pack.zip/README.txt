BACKROOMS-INSPIRED RED CORRIDOR — DIGITAL 3D ENVIRONMENT

A new 3D environment based on the user's reference image: a long, narrow crimson corridor with repeating overhead lamps, luminous EXIT signs, dark door recesses, wall panels, floor seams, and a central vanishing point. This is an original digital scene inspired by the reference, not a photograph.

Files
- backrooms_red_corridor.glb — recommended colored 3D environment, with named scene components and emissive sign/light meshes.
- backrooms_red_corridor.obj — Wavefront geometry alternative; use the GLB for the authored material appearance.
- backrooms-red-corridor-thumbnail.png — 1600 × 900 rendered preview from the GLB in the supplied moody red-lit viewer.
- view_red_corridor.html — interactive browser viewer. Keep it beside the GLB and serve over HTTP/HTTPS. The page uses Three.js from a CDN and adds scene fog and point lights for the reference-like red atmosphere.
- build_red_corridor.py — procedural geometry source.

Approximate GLB bounding dimensions: 5.1 m wide × 32 m long × 3.64 m high, based on the concept geometry and not real architectural specifications.

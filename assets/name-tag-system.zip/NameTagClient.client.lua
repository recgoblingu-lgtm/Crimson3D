-- NameTagClient.client.lua
-- Place this LocalScript in StarterPlayer > StarterPlayerScripts.
-- Requires NameTagServer.server.lua in ServerScriptService for multiplayer-safe saving/filtering.

local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local player = Players.LocalPlayer
local updateRemote = ReplicatedStorage:WaitForChild("NameTagUpdate")

local COLORS = {
    White = Color3.fromRGB(255, 255, 255), Gold = Color3.fromRGB(255, 211, 77),
    Cyan = Color3.fromRGB(67, 220, 255), Pink = Color3.fromRGB(255, 110, 191),
    Green = Color3.fromRGB(102, 235, 139), Red = Color3.fromRGB(255, 105, 105),
    Purple = Color3.fromRGB(185, 130, 255),
}

local gui = Instance.new("ScreenGui")
gui.Name = "NameTagEditor"
gui.ResetOnSpawn = false
gui.DisplayOrder = 30
gui.Parent = player:WaitForChild("PlayerGui")

local function corner(parent, radius)
    local c = Instance.new("UICorner")
    c.CornerRadius = UDim.new(0, radius or 8)
    c.Parent = parent
end

local function makeLabel(parent, text, size, position, color)
    local label = Instance.new("TextLabel")
    label.BackgroundTransparency = 1
    label.Text = text
    label.TextColor3 = color or Color3.fromRGB(235, 240, 255)
    label.Font = Enum.Font.GothamMedium
    label.TextSize = size
    label.Position = position
    label.Size = UDim2.new(1, 0, 0, size + 8)
    label.Parent = parent
    return label
end

-- Small corner card showing the current tag.
local preview = Instance.new("Frame")
preview.Name = "NameTagPreview"
preview.AnchorPoint = Vector2.new(0, 1)
preview.Position = UDim2.new(0, 18, 1, -18)
preview.Size = UDim2.fromOffset(220, 58)
preview.BackgroundColor3 = Color3.fromRGB(16, 20, 33)
preview.BackgroundTransparency = 0.08
preview.Parent = gui
corner(preview, 10)
local previewStroke = Instance.new("UIStroke")
previewStroke.Color = Color3.fromRGB(74, 88, 125)
previewStroke.Parent = preview
makeLabel(preview, "YOUR NAME TAG", 10, UDim2.fromOffset(12, 5), Color3.fromRGB(142, 157, 190))
local previewText = makeLabel(preview, "", 15, UDim2.fromOffset(12, 22), Color3.fromRGB(255, 211, 77))
previewText.TextXAlignment = Enum.TextXAlignment.Left

-- Center button that opens the editor.
local openButton = Instance.new("TextButton")
openButton.Name = "EditNameTagButton"
openButton.AnchorPoint = Vector2.new(0.5, 1)
openButton.Position = UDim2.new(0.5, 0, 1, -18)
openButton.Size = UDim2.fromOffset(180, 40)
openButton.BackgroundColor3 = Color3.fromRGB(70, 93, 220)
openButton.Text = "EDIT NAME TAG"
openButton.TextColor3 = Color3.fromRGB(255, 255, 255)
openButton.Font = Enum.Font.GothamBold
openButton.TextSize = 14
openButton.Parent = gui
corner(openButton, 10)

-- Dimmed overlay and centered editor panel.
local overlay = Instance.new("Frame")
overlay.BackgroundColor3 = Color3.fromRGB(0, 0, 0)
overlay.BackgroundTransparency = 0.4
overlay.Size = UDim2.fromScale(1, 1)
overlay.Visible = false
overlay.Parent = gui

local panel = Instance.new("Frame")
panel.AnchorPoint = Vector2.new(0.5, 0.5)
panel.Position = UDim2.fromScale(0.5, 0.5)
panel.Size = UDim2.fromOffset(390, 350)
panel.BackgroundColor3 = Color3.fromRGB(22, 28, 46)
panel.Parent = overlay
corner(panel, 14)
local panelStroke = Instance.new("UIStroke")
panelStroke.Color = Color3.fromRGB(83, 101, 153)
panelStroke.Thickness = 2
panelStroke.Parent = panel
makeLabel(panel, "EDIT YOUR NAME TAG", 20, UDim2.fromOffset(24, 18), Color3.fromRGB(255, 255, 255))
makeLabel(panel, "Leave name blank to use your Roblox display name.", 11, UDim2.fromOffset(24, 50), Color3.fromRGB(157, 170, 201))

local function makeBox(name, placeholder, y)
    local box = Instance.new("TextBox")
    box.Name = name
    box.Position = UDim2.fromOffset(24, y)
    box.Size = UDim2.new(1, -48, 0, 38)
    box.BackgroundColor3 = Color3.fromRGB(12, 17, 30)
    box.PlaceholderText = placeholder
    box.PlaceholderColor3 = Color3.fromRGB(115, 128, 160)
    box.Text = ""
    box.TextColor3 = Color3.fromRGB(255, 255, 255)
    box.Font = Enum.Font.Gotham
    box.TextSize = 14
    box.ClearTextOnFocus = false
    box.Parent = panel
    corner(box, 8)
    return box
end

local nameBox = makeBox("NameBox", "Custom name (optional)", 82)
local titleBox = makeBox("TitleBox", "Title next to your name", 130)
makeLabel(panel, "COLOR", 11, UDim2.fromOffset(24, 178), Color3.fromRGB(157, 170, 201))

local chosenColor = "Gold"
local colorButtons = {}
local colorNames = {"White", "Gold", "Cyan", "Pink", "Green", "Red", "Purple"}
for index, colorName in ipairs(colorNames) do
    local button = Instance.new("TextButton")
    button.Name = colorName
    button.Text = ""
    button.Position = UDim2.fromOffset(24 + ((index - 1) * 48), 202)
    button.Size = UDim2.fromOffset(36, 26)
    button.BackgroundColor3 = COLORS[colorName]
    button.Parent = panel
    corner(button, 6)
    colorButtons[colorName] = button
    button.MouseButton1Click:Connect(function()
        chosenColor = colorName
        for _, other in pairs(colorButtons) do other.BorderSizePixel = 0 end
        button.BorderSizePixel = 3
        button.BorderColor3 = Color3.fromRGB(255, 255, 255)
    end)
end
colorButtons[chosenColor].BorderSizePixel = 3
colorButtons[chosenColor].BorderColor3 = Color3.fromRGB(255, 255, 255)

local cancel = Instance.new("TextButton")
cancel.Position = UDim2.fromOffset(24, 282)
cancel.Size = UDim2.fromOffset(155, 42)
cancel.BackgroundColor3 = Color3.fromRGB(53, 62, 88)
cancel.Text = "CANCEL"
cancel.TextColor3 = Color3.fromRGB(230, 235, 250)
cancel.Font = Enum.Font.GothamBold
cancel.TextSize = 13
cancel.Parent = panel
corner(cancel, 8)

local save = cancel:Clone()
save.Name = "Save"
save.Position = UDim2.fromOffset(211, 282)
save.BackgroundColor3 = Color3.fromRGB(70, 170, 111)
save.Text = "SAVE NAME TAG"
save.Parent = panel
corner(save, 8)

local function currentName()
    local custom = player:GetAttribute("NameTagName") or ""
    return custom ~= "" and custom or player.DisplayName
end

local function refreshPreview()
    local name = currentName()
    local title = player:GetAttribute("NameTagTitle") or ""
    previewText.Text = title ~= "" and (name .. "  •  " .. title) or name
    previewText.TextColor3 = COLORS[player:GetAttribute("NameTagColor") or "Gold"] or COLORS.Gold
end

local function addOverheadTag(character)
    local head = character:FindFirstChild("Head") or character:WaitForChild("Head")
    local old = head:FindFirstChild("PlayerNameTag")
    if old then old:Destroy() end

    local billboard = Instance.new("BillboardGui")
    billboard.Name = "PlayerNameTag"
    billboard.Adornee = head
    billboard.AlwaysOnTop = true
    billboard.Size = UDim2.fromOffset(280, 68)
    billboard.StudsOffset = Vector3.new(0, 3.2, 0)
    billboard.Parent = head

    local holder = Instance.new("Frame")
    holder.BackgroundTransparency = 1
    holder.Size = UDim2.fromScale(1, 1)
    holder.Parent = billboard

    local title = makeLabel(holder, "", 13, UDim2.fromOffset(0, 0), Color3.fromRGB(255, 211, 77))
    title.Name = "Title"
    title.TextStrokeTransparency = 0.35
    local name = makeLabel(holder, "", 18, UDim2.fromOffset(0, 22), Color3.fromRGB(255, 255, 255))
    name.Name = "Name"
    name.Font = Enum.Font.GothamBold
    name.TextStrokeTransparency = 0.25

    local function render()
        local custom = player:GetAttribute("NameTagName") or ""
        local tag = player:GetAttribute("NameTagTitle") or ""
        local color = COLORS[player:GetAttribute("NameTagColor") or "Gold"] or COLORS.Gold
        name.Text = custom ~= "" and custom or player.DisplayName
        title.Text = tag
        title.TextColor3 = color
        title.Visible = tag ~= ""
        name.Position = tag ~= "" and UDim2.fromOffset(0, 22) or UDim2.fromOffset(0, 11)
    end
    render()
    for _, attribute in ipairs({"NameTagName", "NameTagTitle", "NameTagColor"}) do
        player:GetAttributeChangedSignal(attribute):Connect(render)
    end
end

local function openEditor()
    nameBox.Text = player:GetAttribute("NameTagName") or ""
    titleBox.Text = player:GetAttribute("NameTagTitle") or ""
    chosenColor = player:GetAttribute("NameTagColor") or "Gold"
    overlay.Visible = true
end

openButton.MouseButton1Click:Connect(openEditor)
cancel.MouseButton1Click:Connect(function() overlay.Visible = false end)
save.MouseButton1Click:Connect(function()
    updateRemote:FireServer({Name = nameBox.Text, Title = titleBox.Text, Color = chosenColor})
    overlay.Visible = false
end)

for _, attribute in ipairs({"NameTagName", "NameTagTitle", "NameTagColor"}) do
    player:GetAttributeChangedSignal(attribute):Connect(refreshPreview)
end
player.CharacterAdded:Connect(addOverheadTag)
if player.Character then addOverheadTag(player.Character) end
refreshPreview()

-- NameTagServer.server.lua
-- Place this Script in ServerScriptService.
-- It validates and filters player-entered name-tag text before replicating it.

local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local TextService = game:GetService("TextService")

local remote = ReplicatedStorage:FindFirstChild("NameTagUpdate")
if not remote then
    remote = Instance.new("RemoteEvent")
    remote.Name = "NameTagUpdate"
    remote.Parent = ReplicatedStorage
end

local COLORS = {
    White = Color3.fromRGB(255, 255, 255),
    Gold = Color3.fromRGB(255, 211, 77),
    Cyan = Color3.fromRGB(67, 220, 255),
    Pink = Color3.fromRGB(255, 110, 191),
    Green = Color3.fromRGB(102, 235, 139),
    Red = Color3.fromRGB(255, 105, 105),
    Purple = Color3.fromRGB(185, 130, 255),
}

local function filterForBroadcast(text, userId)
    text = tostring(text or ""):sub(1, 24)
    if text == "" then return "" end
    local ok, result = pcall(function()
        local filtered = TextService:FilterStringAsync(text, userId)
        return filtered:GetNonChatStringForBroadcastAsync()
    end)
    return ok and result or ""
end

local function setDefaults(player)
    if player:GetAttribute("NameTagName") == nil then player:SetAttribute("NameTagName", "") end
    if player:GetAttribute("NameTagTitle") == nil then player:SetAttribute("NameTagTitle", "") end
    if player:GetAttribute("NameTagColor") == nil then player:SetAttribute("NameTagColor", "White") end
end

Players.PlayerAdded:Connect(setDefaults)
for _, player in ipairs(Players:GetPlayers()) do setDefaults(player) end

remote.OnServerEvent:Connect(function(player, data)
    if typeof(data) ~= "table" then return end

    local colorName = tostring(data.Color or "White")
    if not COLORS[colorName] then colorName = "White" end

    local nameText = filterForBroadcast(data.Name, player.UserId)
    local titleText = filterForBroadcast(data.Title, player.UserId)
    player:SetAttribute("NameTagName", nameText)
    player:SetAttribute("NameTagTitle", titleText)
    player:SetAttribute("NameTagColor", colorName)
end)

# Roblox Name-Tag System

This adds editable overhead name tags plus a small corner preview and centered editor popup.

## Install

1. Put [`NameTagServer.server.lua`](./NameTagServer.server.lua) in **ServerScriptService** as a normal **Script**.
2. Put [`NameTagClient.client.lua`](./NameTagClient.client.lua) in **StarterPlayer > StarterPlayerScripts** as a **LocalScript**.
3. Press Play.

Both scripts are required for multiplayer-safe updates. The server creates the `NameTagUpdate` RemoteEvent automatically and filters player-entered text before broadcasting it.

## Included behavior

- Overhead BillboardGui above every player
- Roblox `DisplayName` is used automatically when the custom name is blank
- Editable custom name
- Editable title/tag shown above the name
- Seven color choices
- Small bottom-left “YOUR NAME TAG” preview
- Bottom-center `EDIT NAME TAG` button
- Centered popup with name field, title field, color picker, Save, and Cancel
- Server-side text filtering and length limits
- Changes replicate to other players

Do not trust client-side text in a multiplayer game; keep the server script installed so Roblox filtering and validation remain authoritative.

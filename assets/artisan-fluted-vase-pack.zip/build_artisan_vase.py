#!/usr/bin/env python3
"""Generate a sculptural, hollow, fluted ceramic vase as a GLB/OBJ asset."""
import os, math
import numpy as np
import trimesh
from scipy.interpolate import PchipInterpolator
from trimesh.visual.material import PBRMaterial

OUT='/home/ubuntu/artisan-vase'
scene=trimesh.Scene()
CERAMIC=PBRMaterial(name='Deep teal vitreous ceramic',baseColorFactor=[.018,.19,.205,1],metallicFactor=.12,roughnessFactor=.22)
GOLD=PBRMaterial(name='Satin antique brass accent',baseColorFactor=[.68,.37,.105,1],metallicFactor=.78,roughnessFactor=.28)
INTERIOR=PBRMaterial(name='Glazed inner surface',baseColorFactor=[.035,.25,.26,1],metallicFactor=.08,roughnessFactor=.27)

# Shape-preserving hand-authored profile: generous belly, tapered shoulder, narrow neck and open rim.
# Height units are metres. Outer and inner profiles are separate sides of one connected, closed vessel shell.
outer_y=np.array([0.000,.018,.045,.090,.155,.235,.330,.420,.495,.565,.635,.700,.755,.805,.865,.925,.960])
outer_r=np.array([.142,.168,.186,.204,.241,.282,.309,.300,.267,.221,.169,.132,.122,.128,.141,.154,.158])
inner_y=np.array([.960,.925,.865,.805,.755,.700,.635,.565,.495,.420,.330,.235,.155,.100,.068])
inner_r=np.array([.126,.128,.118,.107,.101,.110,.144,.191,.235,.260,.268,.239,.195,.145,.076])
outer_fn=PchipInterpolator(outer_y,outer_r)
# Inner array is descending; reverse for monotonic PCHIP, then evaluate in top-to-bottom order.
inner_fn=PchipInterpolator(inner_y[::-1],inner_r[::-1])
NTH=240; u=np.linspace(0,1,181);theta=np.arange(NTH)*2*np.pi/NTH
vertices=[];faces=[];rings=[]

def ripple(y,depth=1.0):
    env=np.clip((y-.045)/.18,0,1)*np.clip((.925-y)/.28,0,1)
    env=np.sin(np.clip(env,0,1)*np.pi/2)**.7
    return depth*.0145*env*np.cos(20*theta+2.5*y)

def add_profile(ys,rs,inside=False):
    start=len(vertices);ringids=[]
    for y,r in zip(ys,rs):
        amp=ripple(y,.44 if inside else 1.)
        rr=r+amp
        ring=np.column_stack([rr*np.cos(theta),np.full(NTH,y),rr*np.sin(theta)])
        vertices.extend(ring.tolist());ringids.append(np.arange(start+len(ringids)*NTH,start+(len(ringids)+1)*NTH))
    for q in range(len(ringids)-1):
        a=ringids[q];b=ringids[q+1]
        for j in range(NTH):
            j2=(j+1)%NTH
            if inside:faces.extend([(a[j],b[j],b[j2]),(a[j],b[j2],a[j2])])
            else:faces.extend([(a[j],b[j],b[j2]),(a[j],b[j2],a[j2])])
    return ringids

outer_vals=outer_fn(np.linspace(outer_y[0],outer_y[-1],len(u)))
outer_rings=add_profile(np.linspace(outer_y[0],outer_y[-1],len(u)),outer_vals)
# Hollow interior tapers to a thick, closed bottom, with no artificial cork or filler.
inner_samples=np.linspace(inner_y[0],inner_y[-1],115)
inner_vals=inner_fn(inner_samples)
# Build all inner rings, including a single rim ring, so no duplicate vertices leave a seam.
inner_rings=add_profile(inner_samples,inner_vals,inside=True)
outer_top=outer_rings[-1];inner_top=inner_rings[0]
# Mouth bridge joins the outer lip to the inner wall; the center remains open.
for j in range(NTH):
    j2=(j+1)%NTH
    faces.extend([(outer_top[j],inner_top[j],inner_top[j2]),(outer_top[j],inner_top[j2],outer_top[j2])])
inner_bottom=inner_rings[-1]
# Each side of the ceramic bottom is capped separately at its own wall edge.
outer_bottom=outer_rings[0]
center_outer=len(vertices);vertices.append([0.,outer_y[0],0.])
for j in range(NTH):
    j2=(j+1)%NTH
    faces.append((center_outer,outer_bottom[j],outer_bottom[j2]))
# Interior floor faces upward into the hollow cavity; the vase mouth remains open.
center_inner=len(vertices);vertices.append([0.,inner_y[-1]-.004,0.])
for j in range(NTH):
    j2=(j+1)%NTH
    faces.append((center_inner,inner_bottom[j2],inner_bottom[j]))
# Inner and outer walls/lip are connected as one single closed ceramic body.
shell=trimesh.Trimesh(vertices=np.array(vertices),faces=np.array(faces),process=True)
shell.visual.material=CERAMIC
scene.add_geometry(shell,node_name='Hollow fluted ceramic vase body',geom_name='Hollow fluted ceramic vase body')

# Fine satin-brass rings follow the neck and foot; each is a true connected toroidal band.
def torus_y(name,major,tube,y,material,segments=192,minor_segments=16):
    verts=[];fs=[]
    for i in range(segments):
        a=2*np.pi*i/segments
        for j in range(minor_segments):
            b=2*np.pi*j/minor_segments
            rad=major+tube*np.cos(b)
            verts.append([rad*np.cos(a),y+tube*np.sin(b),rad*np.sin(a)])
    for i in range(segments):
        for j in range(minor_segments):
            a=i*minor_segments+j;b=i*minor_segments+(j+1)%minor_segments;c=((i+1)%segments)*minor_segments+(j+1)%minor_segments;d=((i+1)%segments)*minor_segments+j
            fs.extend([(a,b,c),(a,c,d)])
    m=trimesh.Trimesh(vertices=np.array(verts),faces=np.array(fs),process=True);m.visual.material=material
    scene.add_geometry(m,node_name=name,geom_name=name)

torus_y('Raised brass foot fillet',.184,.0042,.062,GOLD)
torus_y('Fine brass foot pinstripe',.190,.0021,.082,GOLD)
torus_y('Sculpted brass neck band',.124,.004,.777,GOLD)
torus_y('Fine rim accent',.155,.0028,.947,GOLD)
# Small evenly spaced brass dots at the shoulder, used as tasteful maker's ornament (not branding).
for i in range(12):
    a=2*np.pi*i/12;y=.665
    r=float(outer_fn(y))+float(ripple(y,1)[int(i*NTH/12)])+.002
    p=np.array([r*np.cos(a),y,r*np.sin(a)])
    # Low-relief bead, scaled into a tiny oval fleuron.
    bead=trimesh.creation.icosphere(subdivisions=2,radius=1)
    bead.apply_scale([.008,.013,.008]);bead.apply_translation(p);bead.visual.material=GOLD
    scene.add_geometry(bead,node_name=f'Shoulder brass bead {i+1:02d}',geom_name=f'Shoulder brass bead {i+1:02d}')

scene.metadata['title']='Aureline No. 20 — Artisan Fluted Vase'
scene.metadata['units']='meters'
scene.metadata['description']='Hollow sculptural fluted ceramic vase with a twenty-ridge twisting body, shape-preserving handmade silhouette, glazed dark teal finish and satin brass neck/foot accents. Digital concept model; not a fired or manufactured object.'
scene.export(f'{OUT}/artisan_fluted_vase.glb')
scene.export(f'{OUT}/artisan_fluted_vase.obj',file_type='obj')
print('Components:',len(scene.geometry))
print('Bounds (m):',scene.bounds.round(4).tolist())
print('Shell watertight:',shell.is_watertight,'body faces:',len(shell.faces))
print('GLB bytes:',os.path.getsize(f'{OUT}/artisan_fluted_vase.glb'))

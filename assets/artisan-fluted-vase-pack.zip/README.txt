AURELINE — ARTISAN-INSPIRED FLUTED VASE

A sculptural, hollow vase concept with a twisting twenty-ridge fluted body, shaped shoulder and narrow neck, open mouth, thick closed base, glazed deep-teal appearance, and satin-brass accent rings and beads.

Included files: artisan_fluted_vase.glb (recommended colored model), artisan_fluted_vase.obj (geometry alternative; material/color interpretation varies by importer), artisan-vase-preview.png (1600 × 1000 render from the GLB), view_artisan_vase.html (interactive browser preview, best served over HTTP/HTTPS beside the GLB), and build_artisan_vase.py (procedural model source).

Approximate digital bounding dimensions: 0.65 m diameter × 0.96 m high. These values describe the model at its authored scale, not a verified manufactured-product specification. The main hollow ceramic shell is a single watertight mesh with an open mouth and closed base.

This is a digital concept model, not a fired ceramic object, manufacturing drawing, or tested container. Its ability to hold water, food safety, firing shrinkage, wall strength, and durability have not been verified.

#!/usr/bin/env python3
"""Build a premium ergonomic office chair and export GLB/OBJ assets."""
import math
import numpy as np
import trimesh
from trimesh.transformations import rotation_matrix
from trimesh.visual.material import PBRMaterial

OUT = '/home/ubuntu/office-chair-deliverables'
scene = trimesh.Scene()

# Physically plausible, understated product palette.
MAT = {
    'mesh': (49, 57, 60, 255),
    'frame': (31, 37, 40, 255),
    'cushion': (39, 43, 45, 255),
    'metal': (115, 124, 128, 255),
    'darkmetal': (57, 63, 66, 255),
    'rubber': (20, 22, 23, 255),
    'accent': (71, 80, 83, 255),
}

def paint(mesh, color):
    mesh.visual.face_colors = np.array(color, dtype=np.uint8)
    return mesh

def add(mesh, name, color):
    paint(mesh, color)
    scene.add_geometry(mesh, node_name=name, geom_name=name)
    return mesh

def sphere(name, center, scale, color, subdivisions=3):
    m = trimesh.creation.icosphere(subdivisions=subdivisions, radius=1.0)
    m.apply_scale(scale)
    m.apply_translation(center)
    return add(m, name, color)

def cylinder_between(name, a, b, radius, color, sections=20, radius2=None):
    a, b = np.array(a, float), np.array(b, float)
    vec = b - a
    length = np.linalg.norm(vec)
    if length < 1e-8: return
    if radius2 is None:
        m = trimesh.creation.cylinder(radius=radius, height=length, sections=sections)
    else:
        m = trimesh.creation.cone(radius=radius, height=length, sections=sections)
    z = vec / length
    q = trimesh.geometry.align_vectors([0, 0, 1], z)
    m.apply_transform(q)
    m.apply_translation((a + b) / 2)
    add(m, name, color)

def tube_path(name, points, radius, color, sections=12):
    pts = [np.array(p, float) for p in points]
    for i, (a, b) in enumerate(zip(pts[:-1], pts[1:])):
        cylinder_between(f'{name}_{i+1}', a, b, radius, color, sections)
    for i, p in enumerate(pts[1:-1]):
        sphere(f'{name}_joint_{i+1}', p, [radius, radius, radius], color, 2)

def rounded_box(name, extents, center, radius, color, subdivisions=3):
    # Superellipsoid mapped from a unit sphere gives continuously rounded upholstery.
    u = np.linspace(0, 2*np.pi, 64, endpoint=False)
    v = np.linspace(-np.pi/2, np.pi/2, 33)
    uu, vv = np.meshgrid(u, v)
    e = 0.45
    cv, sv = np.cos(vv), np.sin(vv)
    cu, su = np.cos(uu), np.sin(uu)
    sp = lambda x, p: np.sign(x) * np.abs(x)**p
    xyz = np.stack([sp(cv,e)*sp(cu,e), sp(cv,e)*sp(su,e), sp(sv,e)], axis=-1)
    xyz *= np.array(extents)[None,None,:]/2
    xyz += np.array(center)
    rows, cols = xyz.shape[:2]
    vertices = xyz.reshape(-1,3)
    faces=[]
    for j in range(rows-1):
        for i in range(cols):
            i2=(i+1)%cols
            a=j*cols+i; b=j*cols+i2; c=(j+1)*cols+i2; d=(j+1)*cols+i
            faces.extend([(a,b,c),(a,c,d)])
    # Triangulate the end caps to keep every face a consistent triangle.
    faces.extend([(0, i+1, i) for i in range(1, cols-1)])
    top=(rows-1)*cols
    faces.extend([(top, top+i, top+i+1) for i in range(1, cols-1)])
    m=trimesh.Trimesh(vertices=vertices, faces=np.array(faces), process=True)
    return add(m,name,color)

# Upholstered ergonomic seat, slightly domed with a pronounced front lip.
rounded_box('Seat cushion - contoured charcoal upholstery', (0.62,0.55,0.145), (0,0.075,0.535), .035, MAT['cushion'])
# Subtle front-edge welt and underside pan.
cylinder_between('Seat pan center spine',(0,-.12,.465),(0,.24,.465),.025,MAT['darkmetal'])
rounded_box('Seat underside mechanism housing',(0.39,0.34,0.085),(0,-.005,.435),.02,MAT['darkmetal'])

# Curved breathable back panel: dense open-grid impression from molded ribs over dark mesh.
def back_point(u,v,offset=0):
    # u lateral (-1..1), v rises from lumbar to shoulders (0..1)
    width = 0.276 * (0.83 + 0.17*math.sin(math.pi*v))
    x = u * width
    z = 0.700 + 0.545*v
    y = -0.225 - 0.050*(1-u*u) - 0.020*math.sin(math.pi*v) + offset
    # gentle ergonomic lumbar scallop
    z += 0.014*(1-u*u)*math.exp(-((v-.20)/.17)**2)
    return [x,y,z]

nu,nv=32,38
verts=[]
for j in range(nv+1):
    v=j/nv
    for i in range(nu+1):
        u=2*i/nu-1
        verts.append(back_point(u,v))
faces=[]
for j in range(nv):
    for i in range(nu):
        a=j*(nu+1)+i; b=a+1; d=(j+1)*(nu+1)+i; c=d+1
        faces.extend([(a,b,c),(a,c,d)])
panel_faces=np.array(faces)
# Add reversed triangles so the thin woven panel remains opaque from either side.
panel_faces=np.vstack((panel_faces,panel_faces[:,::-1]))
meshpanel=trimesh.Trimesh(vertices=np.array(verts),faces=panel_faces,process=True)
add(meshpanel,'Breathable woven backrest panel',MAT['mesh'])
# Perimeter molded frame around the mesh silhouette.
edge=[]
for i in range(21): edge.append(back_point(-1+2*i/20,0))
for j in range(1,31): edge.append(back_point(1,j/30))
for i in range(1,21): edge.append(back_point(1-2*i/20,1))
for j in range(29,0,-1): edge.append(back_point(-1,j/30))
tube_path('Backrest sculpted perimeter frame',edge,.014,MAT['frame'],14)
# Slim tension ribs give the technical woven surface visible detail.
for k in range(1,13):
    u=-1+2*k/13
    tube_path(f'Mesh vertical thread {k:02d}',[back_point(u,j/20,-.003) for j in range(21)],.0017,(100,110,114,255),6)
for k in range(1,18):
    v=k/18
    tube_path(f'Mesh horizontal thread {k:02d}',[back_point(-1+2*i/24,v,-.004) for i in range(25)],.0015,(100,110,114,255),6)
# Side rails connect the backrest directly into the under-seat frame.
for side in (-1,1):
    x=side*.255
    tube_path(f'Backrest side support {side:+d}',[(side*.16,-.11,.395),(side*.175,-.16,.46),(side*.21,-.205,.55),(x,-.225,.68),(side*.278,-.245,.82),(side*.275,-.255,1.13),(side*.238,-.25,1.25)],.022,MAT['frame'])
tube_path('Backrest crown accent',[back_point(-.72,1),back_point(0,1),back_point(.72,1)],.009,MAT['accent'])

# Adjustable armrests: sculpted padded caps with sturdy two-post supports.
for side,label in [(-1,'Left'),(1,'Right')]:
    x=side*.382
    sphere(f'{label} armrest soft top',(x,-.008,.705),(.072,.205,.032),MAT['cushion'],3)
    for dy,dxshift in [(-.115,-.008),(.13,.006)]:
        px=x+dxshift
        # Each post runs from the underside pan to the bottom of the arm pad.
        cylinder_between(f'{label} armrest upright {dy:+.2f}',(px,dy,.435),(px,dy,.685),.018,MAT['darkmetal'])
        # Crossbar visibly enters the under-seat pan, rather than ending beside it.
        cylinder_between(f'{label} armrest under-seat mount {dy:+.2f}',(px,dy,.445),(side*.17,dy,.445),.019,MAT['metal'])
    tube_path(f'{label} armrest mounting yoke',[(side*.34,-.115,.445),(side*.35,-.115,.51),(side*.36,-.115,.64),(side*.36,-.115,.685)],.013,MAT['frame'])

# Central tilt plate, telescoping gas lift, collar and cover.
rounded_box('Tilt control plate',(0.30,0.25,0.055),(0,-.015,.385),.015,MAT['darkmetal'])
cylinder_between('Gas lift outer sleeve',(0,0,.14),(0,0,.415),.045,MAT['metal'],32)
cylinder_between('Gas lift inner piston',(0,0,.35),(0,0,.49),.026,MAT['darkmetal'],28)
cylinder_between('Gas lift adjustment collar',(0,0,.40),(0,0,.435),.057,MAT['accent'],32)
# Small reachable adjustment lever.
tube_path('Tilt adjustment lever',[(.13,-.05,.40),(.20,-.08,.37),(.24,-.08,.37)],.009,MAT['metal'])

# Five swept, tapered aluminum spokes and molded end caps.
for i in range(5):
    ang=math.radians(90+i*72)
    ux,uy=math.cos(ang),math.sin(ang)
    p0=np.array([0.,0.,.17]); p1=np.array([ux*.20,uy*.20,.155]); p2=np.array([ux*.44,uy*.44,.12]); p3=np.array([ux*.515,uy*.515,.115])
    cylinder_between(f'Five-star base spoke {i+1} inner',p0,p1,.048,MAT['metal'],24)
    cylinder_between(f'Five-star base spoke {i+1} outer',p1,p3,.036,MAT['metal'],24)
    sphere(f'Base spoke end cap {i+1}',p3,(.055,.055,.032),MAT['accent'],2)
# central hub cover
cylinder_between('Five-star hub cover',(0,0,.115),(0,0,.205),.092,MAT['metal'],32)

# Five dual-wheel caster assemblies, with fork stems and realistic rubber wheels.
for i in range(5):
    ang=math.radians(90+i*72)
    ux,uy=math.cos(ang),math.sin(ang)
    cx,cy=ux*.545,uy*.545
    cylinder_between(f'Caster stem {i+1}',(ux*.50,uy*.50,.105),(cx,cy,.105),.018,MAT['darkmetal'],16)
    # Wheel axle lies tangent to the star spoke.
    tx,ty=-uy,ux
    wheel_center=np.array([cx,cy,.075])
    axis=np.array([tx,ty,0.0]); axis/=np.linalg.norm(axis)
    wheel=trimesh.creation.cylinder(radius=.053,height=.040,sections=24)
    wheel.apply_transform(trimesh.geometry.align_vectors([0,0,1],axis))
    wheel.apply_translation(wheel_center)
    add(wheel,f'Dual caster wheel {i+1} A',MAT['rubber'])
    wheel2=trimesh.creation.cylinder(radius=.053,height=.040,sections=24)
    wheel2.apply_transform(trimesh.geometry.align_vectors([0,0,1],axis))
    wheel2.apply_translation(wheel_center+axis*.045)
    add(wheel2,f'Dual caster wheel {i+1} B',MAT['rubber'])
    # Fork sides around both wheels.
    for side in (-1,1):
        off=axis*side*.039
        cylinder_between(f'Caster fork {i+1} side {side:+d}',[cx+off[0],cy+off[1],.09],[cx+off[0],cy+off[1],.145],.009,MAT['darkmetal'],12)

# Export measured, origin-centered scene. Model units are metres.
scene.metadata['title']='Mesh Office Chair - 3D Design Concept'
scene.metadata['units']='meters'
scene.metadata['description']='Concept 3D model of a mesh office chair. Digital design asset only; no physical product or performance testing is represented.'
# Construction used Z-up, but glTF viewers conventionally interpret Y as up.
# Rotate the full assembled scene so its base lies in XZ and the chair stands on +Y.
zup_to_yup = trimesh.transformations.rotation_matrix(-math.pi/2, [1, 0, 0])
scene.apply_transform(zup_to_yup)
scene.export(f'{OUT}/aeroform_ergonomic_office_chair.glb')
# Also provide a Wavefront mesh for workflows that prefer OBJ.
scene.export(f'{OUT}/aeroform_ergonomic_office_chair.obj', file_type='obj')
print(f'Exported {len(scene.geometry)} named components')
print('Bounds (m):', scene.bounds.tolist())
print('GLB bytes:', __import__('os').path.getsize(f'{OUT}/aeroform_ergonomic_office_chair.glb'))

MESH OFFICE CHAIR — DIGITAL 3D DESIGN CONCEPT

This download contains a concept-level digital 3D chair asset. It does not include a physical chair.

Included files
- aeroform_ergonomic_office_chair.glb — recommended format; loads as a Y-up scene with separate named components and color data.
- aeroform_ergonomic_office_chair.obj — Wavefront geometry alternative. Vertex colors are included as an OBJ extension; color display depends on importer support. Prefer GLB for appearance.
- office-chair-sales-thumbnail.png — 1600 × 900 preview rendered directly from the included GLB. It is a model render, not a photograph of a real manufactured product.
- view_chair.html — optional browser preview page. Keep it beside the GLB and serve both over HTTP/HTTPS; the page uses Three.js from a CDN.
- build_office_chair.py — procedural source used to generate the 3D geometry.

Model envelope at the included scale: about 1.16 m wide × 1.12 m deep × 1.24 m high (bounding-box dimensions, not verified real-world product specifications).

Limitations and disclosure
This is a visual 3D concept asset, not manufacturing-ready CAD, a physical product, or an engineering specification. The geometry and mechanisms have not been evaluated for safety, strength, durability, comfort, ergonomic performance, regulatory compliance, or fit. Do not use the render to imply such testing or verified product functionality.
